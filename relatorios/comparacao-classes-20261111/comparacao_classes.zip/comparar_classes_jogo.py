"""Experimento isolado: usa os resolvedores reais do bot com SQLite em memoria.

Nao acessa Discord nem o banco do servidor. Nao altera regras ou conteudo.
Desliga apenas renderizacao, mensagens e pagamentos apos o confronto.
"""
from __future__ import annotations
import argparse
import asyncio
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

REPO = Path(os.environ.get('BOT_INCURSOES_REPO', '/workspace/work/Bot-Incursoes'))
sys.path[:0] = [str(REPO), str(REPO / 'tests'), str(REPO / 'tools')]
import aiosqlite
from src import ameaca, classes, consequencias, database as db, incursoes as I, motor, rules
from src.cogs.incursao import Incursoes
import simular_balanceamento as sb
from fakes import FakeBot, FakeCanal, FakeInteraction, CANAL, GUILD, iniciativa_de_verdade, montar_conteudo

SEED = 20261111
OUT = Path(os.environ.get('BOT_INCURSOES_RESULTADOS', '/workspace/output/comparacao-classes-20261111'))
CORES = {
    'A': ['guerreiro', 'patrulheiro', 'mago', 'clerigo'],
    'B': ['barbaro', 'ladino', 'feiticeiro', 'xama'],
    'C': ['guerreiro', 'clerigo'],
    'D': ['barbaro', 'mago'],
}
ENCONTROS = {
    1: [('bando', [('Bandido',6)]), ('fisico',[('Bugbear',4)]), ('controle',[('Carniçal',4)]), ('chefe',[('Ogro',2)])],
    2: [('bando',[('Doppelganger',4)]), ('fisico',[('Urso-Coruja',3)]), ('controle',[('Múmia',2)]), ('area',[('Crânio Flamejante',2)])],
    3: [('bando',[('Ogro',6)]), ('fisico',[('Gigante da Pedra',2)]), ('controle',[('Devorador de Mentes',2)]), ('area',[('Dragão Verde Jovem',1)])],
    4: [('bando',[('Troll',4)]), ('fisico',[('Gigante da Tempestade',1)]), ('controle',[('Observador',1)]), ('area',[('Dragão Branco Adulto',1)])],
    5: [('bando',[('Gigante do Gelo',3)]), ('fisico',[('Balor',1)]), ('controle',[('Cavaleiro da Morte',1)]), ('area',[('Dragão Vermelho Adulto',1)])],
}


class Bancada(Incursoes):
    def __init__(self, bot):
        super().__init__(bot)
        self.final = None
        self.acoes = Counter()
        self.dano = self.cura = self.thp = 0
        self.quedas = set()

    async def _atualizar_painel(self, *a, **kw): pass
    async def _anunciar_habilidade(self, *a, **kw): pass
    async def _dizer(self, *a, **kw): pass
    def _registrar(self, *a, **kw): pass

    async def _encerrar_combate(self, run, sala, estado):
        self.final = estado
        await self._devolver_pendentes(run)
        await db.atualizar_run(self.bot.db, run['id'], status='sucesso' if estado.inimigos_derrotados else 'fracasso')

    async def _resolver_turno(self, run, estado, uid, turno):
        self.acoes[turno['acao']] += 1
        return await super()._resolver_turno(run, estado, uid, turno)

    async def _vez_do_inimigo(self, run, estado, inimigo, *args):
        result = await super()._vez_do_inimigo(run, estado, inimigo, *args)
        self.quedas.update(c.user_id for c in estado.combatentes if c.caido and not c.e_invocacao)
        return result


def monstros(tier, indice):
    nome, receita = ENCONTROS[tier][indice]
    lista=[]
    for criatura, quantidade in receita:
        achados=I.monstros_de_criatura({'nome':criatura,'quantidade':quantidade}, 'comparacao')
        if not achados: raise ValueError(f'Criatura invalida: {criatura}')
        lista.extend(achados)
    return nome, lista


async def escolher(cog, run, estado, uid):
    p = await cog._personagem_na_run(run, uid)
    c = estado.combatente(uid)
    disponiveis = await cog._habilidades_disponiveis(run, p, cog._passo(run))
    permitidas=[]
    for h, restantes in disponiveis:
        if await cog._aviso_de_requisito(run, estado, uid, h):
            continue
        permitidas.append((1,h))
    c._habilidades_simulador=permitidas
    c._usos_simulador={}
    c._reckless_ativo_simulador=True  # requisito ja conferido pelo proprio bot
    h=sb._escolher_ativa(c, estado.combatentes, estado, estado.rodada)
    if not h:
        return None, []
    a=h.acao or {}
    opcoes=await cog._alvos_possiveis(run,h,estado)
    if not opcoes:
        return h, []
    if a.get('tipo')=='cura' or a.get('alvo') in ('aliado','aliados'):
        permitidos={int(v) for v,_,_ in opcoes}
        candidatos=[x for x in estado.combatentes if x.user_id in permitidos]
        if a.get('tipo')=='cura':
            candidatos.sort(key=lambda x:(x.hp_atual/max(1,x.hp_max),x.user_id))
        else:
            candidatos.sort(key=lambda x:-(sb.media_dado(x.dano_arma)*x.ataques))
        n=a.get('alvos',1)
        n=n if isinstance(n,int) else len(candidatos)
        return h,[x.user_id for x in candidatos[:n]]
    n=a.get('alvos',1)
    n=n if isinstance(n,int) else len(opcoes)
    return h,[int(v) for v,_,_ in opcoes[:n]]


async def lote(classe, tier, modo, indice, repeticoes):
    """Uma celula, todos os sorteios repetiveis e iguais entre classes."""
    inicio=time.perf_counter()
    iniciativa_de_verdade(True)
    conn=await aiosqlite.connect(':memory:')
    conn.row_factory=aiosqlite.Row
    await conn.execute('PRAGMA foreign_keys=ON')
    await db.criar_schema(conn)
    elenco=[classe]*5 if modo=='mono' else CORES[modo]+[classe]
    nivel=rules.nivel_do_tier(tier)
    ids=[]
    escolhas={}
    for pos,cid in enumerate(elenco):
        uid=101+pos
        pid=await db.criar_personagem(conn,GUILD,uid,f'{cid}-{pos}',cid,[],nivel=nivel)
        ids.append(pid)
        escolhas[uid]=sb.escolhas_automaticas(cid,nivel)
        for escolha,opcao in escolhas[uid].items():
            await db.definir_escolha(conn,pid,escolha,opcao)
    nome,criaturas=monstros(tier,indice)
    resultados=[]
    rng_atual=random.Random(SEED)
    motor_rng, ameaca_rng = motor._rng, ameaca._rng
    motor._rng=lambda fornecido=None: fornecido if fornecido is not None else rng_atual
    ameaca._rng=lambda fornecido=None: fornecido if fornecido is not None else rng_atual
    consequencias_rng=consequencias._rng
    consequencias._rng=lambda fornecido=None: fornecido if fornecido is not None else rng_atual
    recarregou_original=I.HabilidadeDoMonstro.recarregou
    I.HabilidadeDoMonstro.recarregou=lambda self,fornecido=None: recarregou_original(self,fornecido if fornecido is not None else rng_atual)
    curar_original,thp_original=motor.curar_quanto,motor.ganhar_thp
    contador={'cura':0,'thp':0}
    def curar(c,quanto):
        ganho=curar_original(c,quanto)
        contador['cura']+=ganho
        return ganho
    def thp(c,quanto):
        ganho=thp_original(c,quanto)
        contador['thp']+=ganho
        return ganho
    motor.curar_quanto, motor.ganhar_thp = curar, thp
    try:
        for tentativa in range(repeticoes):
            # O modo, tier, encontro e repeticao definem a semente; a classe
            # nao entra nela. Cada classe enfrenta os mesmos sorteios-base.
            semente=f'{SEED}:{tier}:{modo}:{indice}:{tentativa}'
            rng_atual=random.Random(semente)
            contador.update(cura=0,thp=0)
            canal=FakeCanal(CANAL)
            cog=Bancada(FakeBot(conn,canal))
            inc,_=montar_conteudo(cog,tier=tier,monstro_objetivo={'nome':'Alvo','ca':10,'hp':100,'ataque':1,'dano':'1d1'})
            inc.objetivo.monstros=list(criaturas)
            runid=await db.criar_run(conn,GUILD,CANAL,inc.id,101)
            for pos,pid in enumerate(ids):
                await db.adicionar_participante(conn,runid,101+pos,pid,tier=tier)
            await db.inicializar_hp(conn,runid)
            await db.atualizar_run(conn,runid,status='objetivo',sala_atual='OBJ',linha_atual=inc.paradas+1)
            run=await db.buscar_run(conn,runid)
            await cog._abrir_combate(run,inc.objetivo)
            cliques=0
            recusas=[]
            while cog.final is None:
                run=await db.buscar_run(conn,runid)
                estado=await cog._estado_combate(run,inc.objetivo)
                if estado.rodada>30:
                    break
                uid=await cog._de_quem_e_a_vez(run,estado)
                if uid is None:
                    await cog._avancar(run,inc.objetivo)
                    cliques+=1
                    if cliques>300: raise RuntimeError('fila sem progresso')
                    continue
                h,alvos=await escolher(cog,run,estado,uid)
                antes=(estado.rodada,uid)
                if h:
                    await cog.usar_habilidade(FakeInteraction(canal,uid),runid,'OBJ',h.id,alvos)
                else:
                    await cog.atacar(FakeInteraction(canal,uid),runid,'OBJ',estado.alvo_preferido().indice)
                cliques+=1
                if cliques>300: raise RuntimeError(f'limite de cliques: {classe} T{tier} {nome}')
            run=await db.buscar_run(conn,runid)
            estado=cog.final or await cog._estado_combate(run,inc.objetivo)
            pcs=[c for c in estado.combatentes if not c.e_invocacao]
            resultados.append({
                'classe':classe,'tier':tier,'modo':modo,'encontro':nome,'repeticao':tentativa,
                'venceu':int(estado.inimigos_derrotados),'rodadas':estado.rodada,
                'hp_pct':100*sum(c.hp_atual for c in pcs)/max(1,sum(c.hp_max for c in pcs)),
                'caidos':sum(c.caido for c in pcs),'quedas':len(cog.quedas),
                'cura':contador['cura'],'thp':contador['thp'],
                'dano_efetivo':sum(m.hp for m in criaturas)-sum(i.hp_atual for i in estado.inimigos),
                'limite':int(cog.final is None),'cliques':cliques,
                'acoes':dict(cog.acoes),
            })
            await conn.execute('DELETE FROM runs WHERE id=?',(runid,))
            await conn.commit()
    finally:
        motor._rng,ameaca._rng=motor_rng,ameaca_rng
        consequencias._rng=consequencias_rng
        I.HabilidadeDoMonstro.recarregou=recarregou_original
        motor.curar_quanto,motor.ganhar_thp=curar_original,thp_original
        await conn.close()
    return {'classe':classe,'tier':tier,'modo':modo,'encontro':nome,'segundos':time.perf_counter()-inicio,'resultados':resultados}


def tarefa(args): return asyncio.run(lote(*args))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--repeticoes',type=int,default=20)
    p.add_argument('--modos',nargs='+',default=['mono','A','B'])
    p.add_argument('--tiers',nargs='+',type=int,default=[1,2,3,4,5])
    p.add_argument('--classes',nargs='+',default=list(classes.CLASSES))
    p.add_argument('--encontros',nargs='+',type=int,default=[0,1,2,3])
    p.add_argument('--processos',type=int,default=4)
    p.add_argument('--nome',default='jogo')
    args=p.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    # Conferir todas as receitas antes de disparar processos.
    for t in args.tiers:
        for i in args.encontros: monstros(t,i)
    tarefas=[(c,t,m,i,args.repeticoes) for t in args.tiers for m in args.modos for i in args.encontros for c in args.classes]
    inicio=time.perf_counter()
    with (OUT/f'{args.nome}.jsonl').open('w') as out:
        with ProcessPoolExecutor(max_workers=args.processos) as pool:
            futuros=[pool.submit(tarefa,t) for t in tarefas]
            for n,futuro in enumerate(as_completed(futuros),1):
                r=futuro.result()
                out.write(json.dumps(r,ensure_ascii=False)+'\n')
                out.flush()
                if n%14==0 or n==len(tarefas):
                    print(f'{n}/{len(tarefas)} celulas; {n*args.repeticoes} combates; {time.perf_counter()-inicio:.1f}s',flush=True)


if __name__=='__main__': main()
